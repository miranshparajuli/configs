
PERMISSIONS AND CREDITS

Terms of Use
- DO NOT use any textures featured in this pack in a published or otherwise distributed project
- DO NOT redistribute this pack or post on ANY external website!!
 * only legit downloads are on Curseforge, Modrinth, and Planet Minecraft posted by PareidoliaG
- DO NOT change or modify this pack and repost without permission
- You CAN use this texture pack in a modpack
- You CAN use these textures in a PERSONAL USE ONLY pack
- You CAN use parts of these textures in addon packs with permission

Texture Credits
- Credits for all textures go to PareidoliaG
- Textures are based on Minecraft book texture by Jappa
- Some textures use palettes/design ideas from supported mods and vanilla